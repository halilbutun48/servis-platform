# Sprint 3 Plan � Review UI + Kalite + Check Paketi

## Hedef
- Geocode sorunlar�n� operasyonel olarak y�netilebilir yap (NEEDS_REVIEW/FAILED)
- Regression test paketini geni�let (Excel�Draft ak���)
- Rota kalitesini art�rmak i�in minimal iyile�tirmeler

## Kapsam (In)
- Company �NEEDS_REVIEW� listesi + manuel d�zeltme
- Manual override korunur
- m-check / fullcheck geni�letme (Sprint 1�2)
- Rota s�ralama MVP: nearest-neighbor (+ opsiyonel 2-opt)

## API
- `GET /api/company/personels?geoStatus=NEEDS_REVIEW`
- `PUT /api/company/personels/:id/location` (lat,lng + geoManualOverride=true)

## DoD
- NEEDS_REVIEW listesi g�r�lebilir
- Manuel d�zeltme sonras� `geoStatus=OK`
- Test pack: import + cache + cluster + draft + approve ak���n� do�rular
