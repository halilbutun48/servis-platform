# Sprint 2 Plan � Otomatik Durak + Draft � ROOM Ak��� (Core)

## Hedef
Excel import + geocode cache (Sprint 1) sonras�:
- Ayn� vardiyadaki personelleri `maxWalkM` kural�yla duraklara b�l
- Duraklar� + ki�i say�lar�n� Shift Draft olarak �ret
- ROOM�a �bekleyen talep� d���r
- ROOM ara� + driver atay�p driver taraf�na rotay�/duraklar� d���r�r

## Kapsam (In)
- Clustering / durak �retimi (maxWalkM garantili)
- Stop - Personel ba�lar� (assignment)
- Shift Draft �retimi + status transition (DRAFT � REQUESTED)
- ROOM approve (ara�+driver ata)
- WS event�leri: `shift:requested`, `shift:approved` (scope�lu)

## Kapsam D��� (Out)
- Company NEEDS_REVIEW UI (Sprint 3)
- Rota optimizasyon (2-opt vs) (Sprint 3/4)
- B�y�k dosya/async pipeline (Sprint 4)

## DB De�i�iklikleri
### StopAssignment (�neri)
- stopId, personelId, shiftId (+ unique/index)

## Service
### `clusterStops(personPoints, maxWalkM)`
- MVP: greedy clustering + medoid stop point
- Do�rulama: her assignment i�in distance <= maxWalkM

## API / �� Ak���
- (Opsiyonel) `POST /api/company/shifts/:id/generate-draft`
- ROOM: `POST /api/room/shifts/:id/approve` (vehicleId, driverId)

## WS
- `shift:requested` � `room:{roomId}` ve `company:{companyId}`
- `shift:approved` � `driver:{driverId}` + ilgili scope

## DoD
- Replace modunda eski durak/assign temizlenip yeniden �retilebilir
- maxWalkM garantisi testle do�rulan�r
- ROOM listesinde draft g�r�n�r, approve edilebilir
- Driver taraf� duraklar� g�r�r
