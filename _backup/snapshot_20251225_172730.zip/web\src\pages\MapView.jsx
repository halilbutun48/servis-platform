import { useEffect, useMemo, useRef, useState } from "react";
import toast from "react-hot-toast";
import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";

function makeEmojiIcon(emoji) {
  return L.divIcon({
    className: "emoji-marker",
    html: `<div style="
      width:34px;height:34px;line-height:34px;
      text-align:center;font-size:28px;
      transform: translate(-50%, -50%);
      user-select:none;
    ">${emoji}</div>`,
    iconSize: [34, 34],
    iconAnchor: [17, 17],
  });
}

const schoolIcon = makeEmojiIcon("🏫");
const busIcon = makeEmojiIcon("🚌");
const stopIcon = makeEmojiIcon("📍");

function FollowToggle({ setAutoFollow, setLockUntilMs }) {
  useMapEvents({
    dragstart() {
      setAutoFollow(false);
      setLockUntilMs(Date.now() + 20_000);
    },
    zoomstart() {
      setAutoFollow(false);
      setLockUntilMs(Date.now() + 20_000);
    },
  });
  return null;
}

function FollowControl({ gps, autoFollow, lockUntilMs }) {
  const map = useMapEvents({});
  const lastRef = useRef(0);

  useEffect(() => {
    if (!gps || !autoFollow) return;
    if (Date.now() < lockUntilMs) return;

    const now = Date.now();
    if (now - lastRef.current < 400) return;
    lastRef.current = now;

    map.setView([gps.lat, gps.lon], Math.max(map.getZoom(), 16), { animate: true });
  }, [gps, autoFollow, lockUntilMs]);

  return null;
}

export default function MapView({ me, socket }) {
  const [autoFollow, setAutoFollow] = useState(true);
  const [lockUntilMs, setLockUntilMs] = useState(0);

  const [gps, setGps] = useState(null);
  const [school, setSchool] = useState(null);
  const [stops, setStops] = useState([]);

  const mapRef = useRef(null);

  const fallbackCenter = useMemo(() => [41.0094, 28.9794], []);
  const schoolCenter = useMemo(() => {
    if (school?.lat != null && school?.lon != null) return [school.lat, school.lon];
    return fallbackCenter;
  }, [school, fallbackCenter]);

  // join rooms (demo: route/vehicle şimdilik 1)
  useEffect(() => {
    if (!socket) return;
    if (me?.schoolId) socket.emit("join", { schoolId: me.schoolId, vehicleId: 1, routeId: 1 });
  }, [socket, me?.schoolId]);

  // WS gps
  useEffect(() => {
    if (!socket) return;
    const onGps = (p) => setGps(p);
    socket.on("gps:update", onGps);
    return () => socket.off("gps:update", onGps);
  }, [socket]);

  // İlk açılış: okul + durak + latest gps
  useEffect(() => {
    (async () => {
      try {
        const token = localStorage.getItem("token") || "";
        const hdrs = token ? { "x-auth-token": token } : {};

        const [schoolRes, stopsRes, gpsRes] = await Promise.all([
          fetch("/api/school/me", { headers: hdrs }).then((r) => r.json()).catch(() => ({})),
          fetch("/api/routes/1/stops", { headers: hdrs }).then((r) => r.json()).catch(() => ({})),
          fetch("/api/gps/latest?vehicleId=1", { headers: hdrs }).then((r) => r.json()).catch(() => ({})),
        ]);

        if (schoolRes?.school) setSchool(schoolRes.school);
        if (Array.isArray(stopsRes?.stops)) setStops(stopsRes.stops);
        if (gpsRes?.last) setGps(gpsRes.last);
      } catch {}
    })();
  }, []);

  // okul geldiğinde (gps yoksa) okula yakınlaştır
  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (gps) return;
    map.setView(schoolCenter, 14, { animate: true });
  }, [schoolCenter, gps]);

  useEffect(() => {
    toast(autoFollow ? "Takip açık" : "Takip kapalı (harita elle oynatıldı)", { id: "follow", duration: 1200 });
  }, [autoFollow]);

  function recenter() {
    const map = mapRef.current;
    if (!map) return;
    const target = gps ? [gps.lat, gps.lon] : schoolCenter;
    setAutoFollow(true);
    setLockUntilMs(0);
    map.setView(target, Math.max(map.getZoom(), 16), { animate: true });
    toast("Merkeze alındı", { id: "recenter", duration: 900 });
  }

  return (
    <div style={{ position: "fixed", inset: 0 }}>
      <div style={{
        position: "absolute", zIndex: 1000, left: 12, top: 12, background: "#fff",
        padding: 10, borderRadius: 10, boxShadow: "0 6px 20px rgba(0,0,0,0.12)"
      }}>
        <div style={{ fontWeight: 700 }}>Harita</div>
        <div style={{ fontSize: 12, opacity: 0.8 }}>Auto-follow: {autoFollow ? "ON" : "OFF"}</div>
        <div style={{ marginTop: 8, display: "flex", gap: 8 }}>
          <button onClick={() => { setAutoFollow(true); setLockUntilMs(0); }}>Takip Aç</button>
          <button onClick={() => setAutoFollow(false)}>Takip Kapat</button>
          <button onClick={recenter}>Recenter</button>
        </div>
        <div style={{ marginTop: 8, fontSize: 12 }}>
          {school ? <>Okul: {school.name}</> : "Okul bekleniyor..."}
        </div>
        <div style={{ marginTop: 4, fontSize: 12 }}>
          {gps ? <>v{gps.vehicleId}: {gps.lat}, {gps.lon}</> : "GPS bekleniyor..."}
        </div>
        <div style={{ marginTop: 4, fontSize: 12 }}>
          Durak: {stops.length}
        </div>
      </div>

      <MapContainer
        center={schoolCenter}
        zoom={14}
        style={{ height: "100%", width: "100%" }}
        whenCreated={(m) => (mapRef.current = m)}
      >
        <TileLayer
          attribution="&copy; OpenStreetMap contributors"
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />

        <FollowToggle setAutoFollow={setAutoFollow} setLockUntilMs={setLockUntilMs} />
        <FollowControl gps={gps} autoFollow={autoFollow} lockUntilMs={lockUntilMs} />

        <Marker position={schoolCenter} icon={schoolIcon} />

        {stops.map((s) => (
          <Marker key={s.id} position={[s.lat, s.lon]} icon={stopIcon} />
        ))}

        {gps && <Marker position={[gps.lat, gps.lon]} icon={busIcon} />}
      </MapContainer>
    </div>
  );
}
